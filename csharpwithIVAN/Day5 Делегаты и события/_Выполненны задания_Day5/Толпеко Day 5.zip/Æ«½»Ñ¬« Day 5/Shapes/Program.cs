﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shapes
{
    public abstract class Shape
    {
        private string color;
        private bool isChosen;

        public string Color
        {
            get { return color; }
            set { color = value; }
        }

        public bool IsChosen
        {
            get { return isChosen; }
            set { isChosen = value; }
        }

        public Shape()
        {
            color = "Цвет не выбран";
            isChosen = false;
        }

        public Shape(string s_color)
        {
            color = s_color;
        }

        public abstract void PrintShape();
    }

    class Rectangle : Shape
    {
        public Rectangle() : base() { }

        public Rectangle(string color) : base(color) { }

        public override void PrintShape()
        {
            Console.WriteLine("********************");
            Console.WriteLine("********************");
            Console.WriteLine("********************");
            Console.WriteLine("********************");
            Console.WriteLine("********************");
        }
    }

    class Rhomb : Shape
    {
        public Rhomb() : base() { }

        public Rhomb(string color) : base(color) { }

        public override void PrintShape()
        {
            Console.WriteLine("       *");
            Console.WriteLine("      ***");
            Console.WriteLine("     *****");
            Console.WriteLine("    *******");
            Console.WriteLine("   *********");
            Console.WriteLine("  ***********");
            Console.WriteLine(" *************");
            Console.WriteLine("***************");
            Console.WriteLine(" *************");
            Console.WriteLine("  ***********");
            Console.WriteLine("   *********");
            Console.WriteLine("    *******");
            Console.WriteLine("     *****");
            Console.WriteLine("      ***");
            Console.WriteLine("       *");
        }
    }

    class Triangle : Shape
    {
        public Triangle() : base() { }

        public Triangle(string color) : base(color) { }

        public override void PrintShape()
        {
            Console.WriteLine("        *");
            Console.WriteLine("       ***");
            Console.WriteLine("      *****");
            Console.WriteLine("     *******");
            Console.WriteLine("    *********");
            Console.WriteLine("   ***********");
            Console.WriteLine("  *************");
            Console.WriteLine(" ***************");
            Console.WriteLine("*****************");
        }
    }

    class Trapeze : Shape
    {
        public Trapeze() : base() { }

        public Trapeze(string color) : base(color) { }

        public override void PrintShape()
        {
            Console.WriteLine("       *******");
            Console.WriteLine("      *********");
            Console.WriteLine("     ***********");
            Console.WriteLine("    *************");
            Console.WriteLine("   ***************");
            Console.WriteLine("  *****************");
            Console.WriteLine(" *******************");
            Console.WriteLine("*********************");
        }
    }

    class Polygon : Shape
    {
        public Polygon() : base() { }

        public Polygon(string color) : base(color) { }

        public override void PrintShape()
        {
            Console.WriteLine("    *********");
            Console.WriteLine("   ***********");
            Console.WriteLine("  *************");
            Console.WriteLine(" ***************");
            Console.WriteLine("*****************");
            Console.WriteLine(" ***************");
            Console.WriteLine("  *************");
            Console.WriteLine("   ***********");
            Console.WriteLine("    *********");
        }
    }

    class GeneralizedShape
    {
        Shape[] shape;

        public GeneralizedShape(int num)
        {
            shape = new Shape[num];
        }

        public Shape[] Shape
        {
            get { return shape; }
            set { shape = value; }
        }

        public void ResizeArr(int newSize)
        {
            Array.Resize(ref shape, newSize);
        }

        public void ShowAllShapes()
        {
            for (int i = 0; i < shape.Length; i++)
            {
                if (shape[i].Color == "красный")
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }

                else if (shape[i].Color == "желтый")
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                }

                else if (shape[i].Color == "зеленый")
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }

                else if (shape[i].Color == "синий")
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                }

                else if (shape[i].Color == "белый")
                {
                    Console.ForegroundColor = ConsoleColor.White;
                }

                if (shape[i].IsChosen == true)
                {
                    shape[i].PrintShape();
                    Console.ForegroundColor = ConsoleColor.Gray;
                }
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int go_on = 1;
            int num = 1;
            int choise = 1;
            GeneralizedShape genShape = new GeneralizedShape(num);
            while (go_on == 1)
            {
                Console.WriteLine("Выберите фигуру:\n1. Прямоугольник\n2. Ромб\n3. Треугольник\n4. Трапеция\n5. Многоугольник");
                choise = Convert.ToInt32(Console.ReadLine());

                while (choise < 1 || choise > 5)
                {
                    Console.WriteLine("Введите число от 1 до 5!");
                    choise = Convert.ToInt32(Console.ReadLine());
                }

                if (choise == 1)
                {
                    genShape.Shape[num - 1] = new Rectangle();
                    genShape.Shape[num - 1].IsChosen = true;
                }

                else if (choise == 2)
                {
                    genShape.Shape[num - 1] = new Rhomb();
                    genShape.Shape[num - 1].IsChosen = true;
                }

                else if (choise == 3)
                {
                    genShape.Shape[num - 1] = new Triangle();
                    genShape.Shape[num - 1].IsChosen = true;
                }

                else if (choise == 4)
                {
                    genShape.Shape[num - 1] = new Trapeze();
                    genShape.Shape[num - 1].IsChosen = true;
                }

                else if (choise == 5)
                {
                    genShape.Shape[num - 1] = new Polygon();
                    genShape.Shape[num - 1].IsChosen = true;
                }

                Console.WriteLine("Выберите цвет фигуры:\n1. Красный\n2. Желтый\n3. Зеленый\n4. Синий\n5. Белый");
                choise = Convert.ToInt32(Console.ReadLine());

                while (choise < 1 || choise > 5)
                {
                    Console.WriteLine("Введите число от 1 до 5!");
                    choise = Convert.ToInt32(Console.ReadLine());
                }

                switch (choise)
                {
                    case 1:
                        genShape.Shape[num - 1].Color = "красный";
                        break;
                    case 2:
                        genShape.Shape[num - 1].Color = "желтый";
                        break;
                    case 3:
                        genShape.Shape[num - 1].Color = "зеленый";
                        break;
                    case 4:
                        genShape.Shape[num - 1].Color = "синий";
                        break;
                    case 5:
                        genShape.Shape[num - 1].Color = "белый";
                        break;
                }

                genShape.ShowAllShapes();

                Console.WriteLine("Хотите выбрать еще одну фигуру? 1 - да, 0 - нет");

                choise = Convert.ToInt32(Console.ReadLine());

                while (choise < 0 || choise > 1)
                {
                    Console.WriteLine("Введите 1 (да) или 0 (нет)!");
                    choise = Convert.ToInt32(Console.ReadLine());
                }

                if (choise == 1)
                {
                    genShape.ResizeArr(num + 1);
                    num++;
                }

                else
                {
                    go_on = 0;
                }
            }
        }
    }
}
