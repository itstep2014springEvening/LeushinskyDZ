﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Race
{
    delegate double Start();

    public abstract class Car
    {
        private string name; // Название автомобиля
        private int id; // Номер автомобиля
        private int speed; // Скорость автомобиля
        private double position; // Расположение автомобиля на трассе в конкретный момент времени

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public double Position
        {
            get { return position; }
            set { position = value; }
        }

        public Car()
        {
            name = "Неизвестное транспортное средство";
            speed = 0;
            position = 0;
        }

        public Car(string n, int sp)
        {
            name = n;
            speed = sp;
            position = sp / 10; // Условная зависимость расстояния от скорости
        }

        public abstract double drive();
    }

    class SportsCars : Car
    {
        public SportsCars() : base("Спортивный автомобиль", 300) { }

        public override double drive()
        {
            Console.ReadKey(true); // Задерживаю каждый раз выполнение метода, чтобы рандомное число было разным (другого способа не придумал)
            Random rand = new Random();
            base.Speed = rand.Next(250, 400);
            base.Position += base.Speed / 10;
            return base.Position;
        }
    }

    class Cars : Car
    {
        public Cars() : base("Легковой автомобиль", 180) { }

        public override double drive()
        {
            Console.ReadKey(true);
            Random rand = new Random();
            base.Speed = rand.Next(100, 220);
            base.Position += base.Speed / 10;
            return base.Position;
        }
    }

    class Trucks : Car
    {
        public Trucks() : base("Грузовой автомобиль", 120) { }

        public override double drive()
        {
            Console.ReadKey(true);
            Random rand = new Random();
            base.Speed = rand.Next(100, 150);
            base.Position += base.Speed / 10;
            return base.Position;
        }
    }

    class Buses : Car
    {
        public Buses() : base("Автобус", 120) { }

        public override double drive()
        {
            Console.ReadKey(true);
            Random rand = new Random();
            base.Speed = rand.Next(80, 120);
            base.Position += base.Speed / 10;
            return base.Position;
        }
    }

    class Game
    {
        Car[] carForRace;
        bool finish;

        public Game(int sports, int cars, int trucks, int buses)
        {
            carForRace = new Car[sports + cars + trucks + buses];
            int num = 1;

            for (int i = 0; i < sports; i++)
            {
                carForRace[i] = new SportsCars();
                carForRace[i].Id = num;
                num++;
            }

            num = 1;

            for (int i = sports; i < sports + cars; i++)
            {
                carForRace[i] = new Cars();
                carForRace[i].Id = num;
                num++;
            }

            num = 1;

            for (int i = sports + cars; i < sports + cars + trucks; i++)
            {
                carForRace[i] = new Trucks();
                carForRace[i].Id = num;
                num++;
            }

            num = 1;

            for (int i = sports + cars + trucks; i < sports + cars + trucks + buses; i++)
            {
                carForRace[i] = new Buses();
                carForRace[i].Id = num;
                num++;
            }

            finish = false;
        }

        public void StartGame()
        {
            Console.WriteLine("Нажимайте каждый раз любую клавишу для отображения статистики конкретного автомобиля");
            Start start = new Start(carForRace[0].drive);
            while (finish == false)
            {
                for (int i = 0; i < carForRace.Length; i++)
                {
                    start = carForRace[i].drive;
                    if (carForRace[i].Position >= 100)
                    {
                        finish = true;
                        Console.WriteLine("Гонка завершена! Победитель: {0} № {1}!", carForRace[i].Name, carForRace[i].Id);
                        break;
                    }

                    else
                    {
                        Console.WriteLine("{0} № {1} проехал: {2}", carForRace[i].Name, carForRace[i].Id, start());
                    }
                }       
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int sports = 0, cars = 0, trucks = 0, buses = 0;
            Console.WriteLine("Сколько спортивных автомобилей участвует в гонке?");
            sports = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Сколько легковых автомобилей участвует в гонке?");
            cars = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Сколько грузовых автомобилей участвует в гонке?");
            trucks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Сколько автобусов участвует в гонке?");
            buses = Convert.ToInt32(Console.ReadLine());
            Game game = new Game(sports, cars, trucks, buses);
            game.StartGame();
        }
    }
}
