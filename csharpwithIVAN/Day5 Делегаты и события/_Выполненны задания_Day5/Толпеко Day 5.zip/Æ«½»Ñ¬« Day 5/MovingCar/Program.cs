﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MovingCar
{
    class Car
    {
        private int distance; // Расстояние
        private int fuel; // Уровень топлива
        private double oil; // Уровень масла

        public int Distance
        {
            get { return distance; }
            set { distance = value; }
        }

        public int Fuel
        {
            get { return fuel; }
            set { fuel = value; }
        }

        public double Oil
        {
            get { return oil; }
            set { oil = value; }
        }

        public Car()
        {
            distance = 0;
            fuel = 60;
            oil = 4;
        }

        public Car(int fuel, double oil)
        {
            distance = 0;
            this.fuel = fuel;
            this.oil = oil;
        }
    }

    class Events
    {
        public event EventHandler move;
        public event EventHandler overheated;
        public event EventHandler noFuel;
        public event EventHandler noOil;

        public void OnEvent(Car car)
        {
            while (car.Distance < 1300 || car.Fuel > 0)
            {
                if (car.Distance >= 1300)
                {
                    overheated(this, EventArgs.Empty);
                    Console.WriteLine("Проехали {0} км.", car.Distance);
                    break;
                }

                else if (car.Fuel <= 0)
                {
                    noFuel(this, EventArgs.Empty);
                    Console.WriteLine("Проехали {0} км.", car.Distance);
                    break;
                }


                else if (car.Oil <= 0)
                {
                    noOil(this, EventArgs.Empty);
                    Console.WriteLine("Проехали {0} км.", car.Distance);
                    break;
                }

                else
                {
                    move(this, EventArgs.Empty);
                    Console.WriteLine("Проехали {0} км.", car.Distance);
                }

                car.Distance += 100;
                car.Fuel -= 2;
                car.Oil -= 0.2;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int fuel = 0;
            double oil = 0;
            Console.WriteLine("Ваш автомобиль обладает следующими характеристиками: расход топлива - 2л/100км, расход масла 0,2л/100км, большая вероятность перегрева двигателя после езды более 1300 км без остановки.");
            Console.WriteLine("Заправьте автомобиль (введите количество литров топлива):");
            fuel = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Залейте масло в автомобиль (введите количество литров масла):");
            oil = Convert.ToDouble(Console.ReadLine());
            Car car = new Car(fuel, oil);
            Events ev = new Events();
            ev.overheated += new EventHandler(OverheatedHandler);
            ev.noFuel += new EventHandler(NoFuelHandler);
            ev.noOil += new EventHandler(NoOilHandler);
            ev.move += new EventHandler(MoveHandler);
            ev.OnEvent(car);
        }

        static void MoveHandler(object source, EventArgs arg)
        {
            Console.Write("Состояние машины: едем. ");
        }

        static void OverheatedHandler(object source, EventArgs arg)
        {
            Console.Write("Состояние машины: перегрев двигателя. ");
        }

        static void NoFuelHandler(object source, EventArgs arg)
        {
            Console.Write("Состояние машины: закончилось топливо. ");
        }

        static void NoOilHandler(object source, EventArgs arg)
        {
            Console.Write("Состояние машины: закончилось масло. ");
        }
    }
}

