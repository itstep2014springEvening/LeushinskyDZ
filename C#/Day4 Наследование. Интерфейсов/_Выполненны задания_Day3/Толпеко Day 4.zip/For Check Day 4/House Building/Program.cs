﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace houseBuilding
{
    public interface IWorker
    {
        void build(House house);
    }

    public interface IPart
    {
        double Area { get; set; }
        bool IsBuilt { get; set; }
    }

    public class House
    {
        private Basement basement;
        private Walls[] walls;
        private Door door;
        private Window[] window;
        private Roof roof;

        public Basement PBasement
        {
            get { return basement; }
            set { basement = value; }
        }

        public Walls[] PWalls
        {
            get { return walls; }
            set { walls = value; }
        }

        public Door PDoor
        {
            get { return door; }
            set { door = value; }
        }

        public Window[] PWindow
        {
            get { return window; }
            set { window = value; }
        }

        public Roof PRoof
        {
            get { return roof; }
            set { roof = value; }
        }

        public House(int wal, int win)
        {
            basement = new Basement();
            walls = new Walls[wal];

            for (int i = 0; i < wal; i++)
            {
                walls[i] = new Walls();
            }

            door = new Door();
            window = new Window[win];

            for (int i = 0; i < win; i++)
            {
                window[i] = new Window();
            }

            roof = new Roof();
        }
    }

    public class Basement : IPart
    {
        private int length; // длина фундамента
        private int width; // ширина фундамента
        private double area; // площадь фундамента
        private bool isBuilt; // фундамент построен?

        public int Length
        {
            get { return length; }
            set { length = value; }
        }

        public int Width
        {
            get { return width; }
            set { width = value; }
        }

        public double Area
        {
            get { return length * width; }
            set { area = value; }
        }

        public bool IsBuilt
        {
            get { return isBuilt; }
            set { isBuilt = value; }
        }

        public Basement()
        {
            length = 0;
            width = 0;
            area = 0;
            isBuilt = false;
        }
    }

    public class Walls : IPart
    {
        private int length; // длина стены
        private int height; // высота стены
        private double area; // площадь стены
        private bool isBuilt; // стены построены?

        public int Length
        {
            get { return length; }
            set { length = value; }
        }

        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        public double Area
        {
            get { return length * height; }
            set { area = value; }
        }

        public bool IsBuilt
        {
            get { return isBuilt; }
            set { isBuilt = value; }
        }

        public Walls()
        {
            length = 0;
            height = 0;
            area = 0;
            isBuilt = false;
        }
    }

    public class Door : IPart
    {
        private int width; // ширина двери
        private int height; // высота двери
        private double area; // площадь двери
        private bool isBuilt; // дверь установлена?

        public int Width
        {
            get { return width; }
            set { width = value; }
        }

        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        public double Area
        {
            get { return width * height; }
            set { area = value; }
        }

        public bool IsBuilt
        {
            get { return isBuilt; }
            set { isBuilt = value; }
        }

        public Door()
        {
            width = 0;
            height = 0;
            area = 0;
            isBuilt = false;
        }
    }

    public class Window : IPart
    {
        private int width; // ширина окна
        private int height; // высота окна
        private double area; // площадь окна
        private bool isBuilt; // окно установлено?

        public int Width
        {
            get { return width; }
            set { width = value; }
        }

        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        public double Area
        {
            get { return width * height; }
            set { area = value; }
        }

        public bool IsBuilt
        {
            get { return isBuilt; }
            set { isBuilt = value; }
        }

        public Window()
        {
            width = 0;
            height = 0;
            area = 0;
            isBuilt = false;
        }
    }

    public class Roof : IPart
    {
        // предполагаю, что крыша скатная: две первые противоположные стороны - равноб. трапеции, две вторые - равноб. треугольники
        private int downLength; // длина нижней части крыши
        private int upLength; // длина верхней части крыши
        private int width; // ширина нижней части крыши
        private int height; // высота крыши
        private double area; // площадь крыши
        private bool isBuilt; // крыша установлена?

        public int DownLength
        {
            get { return downLength; }
            set { downLength = value; }
        }

        public int UpLength
        {
            get { return upLength; }
            set { upLength = value; }
        }

        public int Width
        {
            get { return width; }
            set { width = value; }
        }

        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        public double Area
        {
            get { return (((((upLength + downLength) / 2) * height) + (0.5 * width * height)) * 2); }
            set { area = value; }
        }

        public bool IsBuilt
        {
            get { return isBuilt; }
            set { isBuilt = value; }
        }

        public Roof()
        {
            downLength = 0;
            upLength = 0;
            width = 0;
            height = 0;
            area = 0;
            isBuilt = false;
        }
    }

    public class Team
    {
        private Worker[] workers;

        public Worker[] Workers
        {
            get { return workers; }
            set { workers = value; }
        }

        public Team(int numOfWorkers)
        {
            workers = new Worker[numOfWorkers];

            for (int i = 0; i < workers.Length; i++)
            {
                workers[i] = new Worker();
            }
        }

    }

    public class Worker : IWorker
    {
        public void build(House house)
        {
            if (house.PBasement.IsBuilt == false)
            {
                house.PBasement.IsBuilt = true;
                return;
            }

            for (int i = 0; i < house.PWalls.Length; i++)
            {
                if (house.PWalls[i].IsBuilt == false)
                {
                    house.PWalls[i].IsBuilt = true;
                    return;
                }
            }

            if (house.PDoor.IsBuilt == false)
            {
                house.PDoor.IsBuilt = true;
                return;
            }

            for (int i = 0; i < house.PWindow.Length; i++)
            {
                if (house.PWindow[i].IsBuilt == false)
                {
                    house.PWindow[i].IsBuilt = true;
                    return;
                }
            }

            if (house.PRoof.IsBuilt == false)
            {
                house.PRoof.IsBuilt = true;
                return;
            }
        }
    }

    public class TeamLeader
    {
        private bool finish; // Определяет, закончено ли строительство дома
        int num = 0; // Счетчик для подсчета количества построенных стен и окон

        public bool Finish
        {
            get { return finish; }
        }

        public void check(House house)
        {
            if (house.PBasement.IsBuilt == true)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Фундамент построен");
            }

            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Фундамент не построен");
            }

            for (int i = 0; i < house.PWalls.Length; i++)
            {
                if (house.PWalls[i].IsBuilt == true)
                {
                    num++;
                }
            }

            if (num < house.PWalls.Length)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }

            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }

            Console.WriteLine("Возведено(-а) {0} стены(-а)", num);
            num = 0;

            if (house.PDoor.IsBuilt == true)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Дверь установлена");
            }

            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Дверь не установлена");
            }

            for (int i = 0; i < house.PWindow.Length; i++)
            {
                if (house.PWindow[i].IsBuilt == true)
                {
                    num++;
                }
            }

            if (num < house.PWindow.Length)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }

            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }

            Console.WriteLine("Установлены(-о) {0} окна(-о)", num);
            num = 0;

            if (house.PRoof.IsBuilt == true)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Крыша построена\n");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("СТРОИТЕЛЬСТВО ДОМА ЗАВЕРШЕНО!");
                finish = true;
            }

            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Крыша не построена");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            House house = new House(4, 4);
            Team team = new Team(11); // Будет строить 11 рабочих, каждый по одной части дома (1 + 4 + 1 + 4 + 1)
            TeamLeader teamLeader = new TeamLeader();
            int go_on = 1;
            int begin = 0;
            int end = 0;

            while (go_on == 1)
            {
                Console.WriteLine("Сколько частей дома построить на данном этапе?");
                end = Convert.ToInt32(Console.ReadLine());

                while (begin + end > 11)
                {
                    Console.WriteLine("Введите меньшее число. Осталось построить {0} частей(-и) дома.", 11 - begin);
                    end = Convert.ToInt32(Console.ReadLine());
                }

                end += begin;

                for (int i = begin; i < end; i++)
                {
                    team.Workers[i].build(house);
                }

                begin = end;
                teamLeader.check(house);

                if (teamLeader.Finish == true)
                {
                    go_on = 0;
                    Console.WriteLine("             *");
                    Console.WriteLine("           *  *");
                    Console.WriteLine("         *     *");
                    Console.WriteLine("       *        *");
                    Console.WriteLine("     *           *");
                    Console.WriteLine("    * *           *");
                    Console.WriteLine("   *   *         **");
                    Console.WriteLine("  *     *      *  *");
                    Console.WriteLine(" *       *   *  * *");
                    Console.WriteLine("***********   * * *");
                    Console.WriteLine("*         *  *  * *");
                    Console.WriteLine("***** * * *  * *  *");
                    Console.WriteLine("*   * *   *  *   *");
                    Console.WriteLine("***** *  **    *");
                    Console.WriteLine("*     *   *  *");
                    Console.WriteLine("***********");
                }
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
    }
}
