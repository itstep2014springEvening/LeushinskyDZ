﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Backup
{
    public abstract class Storage
    {
        private string name;
        private string model;
        private int memory;
        private int writtenSpace;
       
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Model
        {
            get { return model; }
            set { model = value; }
        }

        public int Memory
        {
            get { return memory; }
            set { memory = value; }
        }

        public int WrittenSpace
        {
            get { return writtenSpace; }
            set { writtenSpace = value; }
        }

        public Storage(string nam, string mod, int mem)
        {
            Name = nam;
            Model = mod;
            Memory = mem;
            WrittenSpace = 0;
        }

        public abstract int GetMemory();
        public abstract void CopyToDevice();
        public abstract int GetFreeMemory();
        public abstract string GetFullDeviceInfo();
        public abstract int GetTimeForCopy();
    }

    class Flash : Storage
    {
        private int USB3Speed;

        public Flash(string mod, int mem, int speed) : base("Флеш-память", mod, mem)
        {
            USB3Speed = speed;
        }

        public override int GetMemory()
        {
            return Memory;
        }

        public override void CopyToDevice()
        {   
            for (int i = 780; i < Memory; i += 780)
            {
                WrittenSpace += 780;
            }
        }

        public override int GetFreeMemory()
        {
            return Memory - WrittenSpace;
        }

        public override string GetFullDeviceInfo()
        {
            return String.Format("Название: {0}\nМодель: {1}\nПамять: {2} Мбайт\nСкорость USB3: {3} Мбайт/с", Name, Model, Memory, USB3Speed);
        }

        public override int GetTimeForCopy()
        {
            return WrittenSpace / USB3Speed;
        }
    }

    class DVD : Storage
    {
        private int readWriteSpeed;
        private string type;

        public DVD(string mod, int mem, int rwspeed, string t) : base("DVD-диск", mod, mem)
        {
            readWriteSpeed = rwspeed;
            type = t;
        }

        public override int GetMemory()
        {
            return Memory;
        }

        public override void CopyToDevice()
        {
            for (int i = 780; i < Memory; i += 780)
            {
                WrittenSpace += 780;
            }
        }

        public override int GetFreeMemory()
        {
            return Memory - WrittenSpace;
        }

        public override string GetFullDeviceInfo()
        {
            return String.Format("Название: {0}\nМодель: {1}\nПамять: {2} Мбайт\nСкорость чтения-записи: {3} Мбайт/с\nТип: {4}", Name, Model, Memory, readWriteSpeed, type);
        }

        public override int GetTimeForCopy()
        {
            return WrittenSpace / readWriteSpeed;
        }
    }

    class HDD : Storage
    {
        private int USB2Speed;
        private int numOfSections;
        private int amountOfDiskPartitions;

        public HDD(string mod, int mem, int speed, int numOfS, int amOfDiskPart) : base("Съемный HDD", mod, mem)
        {
            USB2Speed = speed;
            numOfSections = numOfS;
            amountOfDiskPartitions = amOfDiskPart;
        }

        public override int GetMemory()
        {
            return Memory;
        }

        public override void CopyToDevice()
        {
            for (int i = 780; i < Memory; i += 780)
            {
                WrittenSpace += 780;
            }
        }

        public override int GetFreeMemory()
        {
            return Memory - WrittenSpace;
        }

        public override string GetFullDeviceInfo()
        {
            return String.Format("Название: {0}\nМодель: {1}\nПамять: {2} Мбайт\nСкорость USB2: {3} Мбайт/с\nКоличество разделов: {4}\nОбъем разделов: {5}", Name, Model, Memory, USB2Speed, numOfSections, amountOfDiskPartitions);
        }

        public override int GetTimeForCopy()
        {
            return WrittenSpace / USB2Speed;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {          
            Storage[] storage = new Storage[3];
            storage[0] = new Flash("Kingston", 16000, 600);
            storage[1] = new DVD("Mirex", 4000, 21, "односторонний");
            storage[2] = new HDD("Toshiba", 500000, 60, 2, 250000);
            Console.WriteLine("Общее количество памяти всех устройств: {0} Мбайт.\n", storage[0].GetMemory() + storage[1].GetMemory() + storage[2].GetMemory());
            for (int i = 0; i < storage.Length; i++)
            {
                storage[i].CopyToDevice();
                Console.WriteLine("Информация о {0}-м носителе:\n", i + 1);
                Console.WriteLine(storage[i].GetFullDeviceInfo());
                Console.WriteLine("Время для копирования {0} Мбайт на DVD: {1} секунд.", storage[i].WrittenSpace, storage[i].GetTimeForCopy());
                Console.WriteLine("Количество носителя для переноса информации: {0}.", 565000 / storage[i].WrittenSpace + 1);
                Console.WriteLine("Время для копирования всей информации в количестве 565 Гб на DVD: более {0} секунд.", 565000 / storage[i].WrittenSpace * storage[i].GetTimeForCopy());
                Console.WriteLine("----------------------------------\n");
            }           
        }
    }
}
